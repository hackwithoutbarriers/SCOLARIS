import { test, expect } from '@playwright/test';

test('les actions de contexte école restent lisibles quand le contexte est actif', async ({ page }) => {
    test.setTimeout(180_000);
    await page.setViewportSize({ width: 1280, height: 800 });
    await page.goto('/admin/login', { waitUntil: 'domcontentloaded' });
    await page.getByLabel('Adresse e-mail ou téléphone').fill('superadmin@example.com');
    await page.getByLabel('Mot de passe').fill('password');

    const loginSubmission = page.waitForResponse((response) => response.url().includes('/livewire/update'));
    await page.getByRole('button', { name: 'Connexion' }).click();
    expect((await loginSubmission).status()).toBe(200);
    await expect(page).toHaveURL(/\/admin\/?$/);

    await page.goto('/admin/school-support', { waitUntil: 'domcontentloaded' });
    await page.getByRole('button', { name: 'Ouvrir le contexte école' }).click();
    await expect(page).toHaveURL(/\/admin\/?$/);
    await page.goto('/admin/school-support', { waitUntil: 'domcontentloaded' });

    const contrast = await page.getByRole('button', { name: 'Configurer l\'école' }).evaluate((button) => {
        const parse = (color) => color.match(/[\d.]+/g).slice(0, 3).map(Number);
        const luminance = (color) => {
            const [red, green, blue] = parse(color).map((value) => {
                const channel = value / 255;
                return channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
            });

            return 0.2126 * red + 0.7152 * green + 0.0722 * blue;
        };
        const style = getComputedStyle(button);
        const background = style.backgroundColor === 'rgba(0, 0, 0, 0)'
            ? getComputedStyle(button.parentElement).backgroundColor
            : style.backgroundColor;
        const values = [luminance(style.color), luminance(background)].sort((a, b) => b - a);

        return { color: style.color, background, ratio: (values[0] + 0.05) / (values[1] + 0.05) };
    });

    expect(contrast.ratio, JSON.stringify(contrast)).toBeGreaterThanOrEqual(4.5);
});
